class User {
  String? userName;
  int? age;
  bool? isMarrid;

  User({this.userName, this.age, this.isMarrid});

  User.fromJson(Map<String, dynamic> json) {
    userName = json['userName'];
    age = json['age'];
    isMarrid = json['isMarrid'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['userName'] = this.userName;
    data['age'] = this.age;
    data['isMarrid'] = this.isMarrid;
    return data;
  }
}
