import 'package:flutter_sqflite/view/user_list/model/user_model.dart';
import 'package:sqflite/sqflite.dart';
import 'package:sqflite/sqlite_api.dart';

class UserDatabaseProvider {
  late String _userDatabaseName = "user";
  late int _version = 1;
  String _tbName = "user";
  String _colUserName = "userName";
  String _colUserAge = "age";
  String _colUserMarrid = "married";
  String _colUserId = "id";
  late Database database;
  void open() async {
    database = await openDatabase(_userDatabaseName,
        singleInstance: true, version: _version, onCreate: (db, version) {
      createTable(db);
    });
  }

  void createTable(db)async {
    await db.execute(
        "CREATE TABLE ${_tbName}($_colUserId INTEGER PRIMARY KEY AUTOINCREMENT,$_colUserName VARCHAR(20),$_colUserMarrid bool,$_colUserAge INTEGER)");
  }

  Future<List<User>> getList() async {
    // database.execute("SELECT * FROM $_tbName ");
    List<Map> userMaps = await database.query(_tbName);
    return userMaps.map((e) => User.fromJson(e)).toList();
  }

  Future<User?> getItem(int id) async {
    final userMap = await database.query(
      _tbName,
      where: "$_colUserId=?",
      whereArgs: [id],
      columns: [_colUserId] ,
    );
    if(userMap.isNotEmpty){
      return User.fromJson(userMap.first);
    }else
    {
      return null;
    }
  }

  Future<bool> deleteUser(int id) async {
    final userMap = await database.delete(
      _tbName,
      where: "$_colUserId=?",
      whereArgs: [id],
    );
    return userMap!=null;
  }

  Future<bool> deleteUpdate(int id,User model) async {
    final userMap = await database.update(
      _tbName,
      model.toJson(),
      where: "$_colUserId=?",
      whereArgs: [id],
    );
    return userMap != null;
  }

  void close(args)async{
    await database.close();
  }

}
